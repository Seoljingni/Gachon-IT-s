package com.example.Gachon_Its;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GachonItsApplication {

	public static void main(String[] args) {
		SpringApplication.run(GachonItsApplication.class, args);
	}

}
